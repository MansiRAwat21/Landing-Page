import React from 'react'
import '../styles/About.css'
import logo from '../assets/logo.png';
const About = () => {
  return (
    <>
    <div id='about'>
        <h1>About</h1>
    </div>

    <div class="side-2">
            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Doloribus perspiciatis sapiente doloremque nemo
              quo temporibus culpa nulla magnam libero fuga beatae, in autem ad sequi neque reiciendis. Quidem
              repellendus nesciunt, reprehenderit dolorem ipsa placeat neque tenetur nostrum dolores fuga cum facilis!
              Fugit eaque debitis recusandae tenetur repudiandae accusamus harum nulla!
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae modi labore impedit sint tempora quia odit cumque! Excepturi odio temporibus, nostrum, architecto, ex numquam molestias enim iure aliquid saepe et.</p>
           
          </div>
      
    </>
  )
}

export default About